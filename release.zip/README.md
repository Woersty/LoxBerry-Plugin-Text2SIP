# LoxBerry-Plugin-Text2SIP
A LoxBerry Plugin
-
For Details visit http://www.loxwiki.eu/display/LOXBERRY/Plugins#Plugins-Text2SIP
